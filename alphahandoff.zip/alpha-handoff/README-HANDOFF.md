# How to install this handoff

Copy into the repo root at `/Users/sanya/Projects/alpha`:

```bash
cd /Users/sanya/Projects/alpha

# 1. Project context — Claude Code reads this automatically every session
cp /path/to/alpha-handoff/CLAUDE.md .

# 2. Strategy, protocol, and briefs
mkdir -p docs/strategy docs/briefs
cp /path/to/alpha-handoff/docs/PHASE1_OPERATING_GUIDE.md docs/
cp /path/to/alpha-handoff/docs/strategy/*.md docs/strategy/
cp /path/to/alpha-handoff/docs/briefs/*.md docs/briefs/

git add CLAUDE.md docs/
git commit -m "docs: add project context, strategy, and validation protocol"
git push
```

## What each file is for

| File | Purpose |
|---|---|
| `CLAUDE.md` | Read automatically by Claude Code. The honest state of the project, the invariants, and what not to build. |
| `docs/PHASE1_OPERATING_GUIDE.md` | For the human, not the agent. Weekly rhythm, checkpoints, stop conditions. |
| `docs/strategy/VALIDATION_PROTOCOL.md` | Pre-registered study design. Read before running any analysis of whether crowding predicts success. |
| `docs/strategy/BUSINESS_MODEL.md` | The eventual product — a research-crowding bureau. Gated behind Phase 2 evidence. |
| `docs/strategy/ROADMAP.md` | Phase sequencing, and why the plan was reordered after the inventory. |
| `docs/strategy/PRODUCT_STRATEGY.md` | Earlier positioning work. Superseded on pricing and market size by the business model. |
| `docs/briefs/*` | The task briefs each phase was built from. Useful as templates for future phases. |

## Note on the strategy documents

They contain revenue estimates, market sizing, and pricing. **All of it is conditional on evidence that does not yet exist.** The roadmap and the operating guide are the load-bearing documents right now; the business model is what happens if Phase 2 comes back positive.

If a future agent reads the business model and starts building product features, that is a misreading. `CLAUDE.md` says so explicitly.
